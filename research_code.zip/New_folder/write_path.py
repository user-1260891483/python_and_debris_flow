# -*- coding: utf-8 -*-
"""
Created on Tue Nov  9 09:06:25 2021

将data文件夹中的数据写成train.json与test.json
使用p指定划分范围
使用时将该文件放在data的上级目录运行

@author: uKey
"""

from pathlib import Path
import random
import os

p = 188     #指示使用多少份数据作为训练集

main_path = Path.cwd()
data_path = Path.cwd()/'/mnt/xfs_code/train_data'
data_file_list = []
label_list = []
folder_list = []

l = list(data_path.iterdir())

for i in l:
    os.chdir(i)
    temp_file_list = list(i.glob("**/*.npy"))
    temp_label_list = [int(i.name)]*len(temp_file_list)
    data_file_list += temp_file_list
    label_list += temp_label_list
    folder_list.append(str(i.name))
    
os.chdir(main_path)

#所有数据一起打乱
all_data = list(zip(label_list,data_file_list))
random.shuffle(all_data)
label_data = [i[0] for i in all_data]
data = [i[1] for i in all_data]

#写入json文件
fo = open('73train3' + ".json", "w")

fo.write('{"label_names": [')
fo.writelines(['"%s",' % item  for item in folder_list])
fo.seek(0, os.SEEK_END) 
fo.seek(fo.tell()-1, os.SEEK_SET)
fo.write('],')

fo.write('"data_path": [')
fo.writelines(['"%s",' % item  for item in data[:p]])
fo.seek(0, os.SEEK_END)
fo.seek(fo.tell()-1, os.SEEK_SET)
fo.write('],')

fo.write('"data_labels": [')
fo.writelines(['%d,' % item  for item in label_data[:p]])
fo.seek(0, os.SEEK_END) 
fo.seek(fo.tell()-1, os.SEEK_SET)
fo.write(']}')

fo.close()

print("Save train.json done")

fo = open('73test3' + ".json", "w")

fo.write('{"label_names": [')
fo.writelines(['"%s",' % item  for item in folder_list])
fo.seek(0, os.SEEK_END) 
fo.seek(fo.tell()-1, os.SEEK_SET)
fo.write('],')

fo.write('"data_path": [')
fo.writelines(['"%s",' % item  for item in data[p:]])
fo.seek(0, os.SEEK_END)
fo.seek(fo.tell()-1, os.SEEK_SET)
fo.write('],')

fo.write('"data_labels": [')
fo.writelines(['%d,' % item  for item in label_data[p:]])
fo.seek(0, os.SEEK_END) 
fo.seek(fo.tell()-1, os.SEEK_SET)
fo.write(']}')

fo.close()

print("Save test.json done")