1、The folder "8_channel_code" contains research data and some code debugging sections. It requires converting image data into JSON files and splitting them into training and testing sets based on different data categories.

2、The main function contains the main execution code, while VGG, ResNet, and the train function contain testing code. The results of the execution are saved as PKL files.

3、The "show_mid_feature" is the part responsible for visualizing network features. It loads the saved parameters from a PKL file and displays intermediate layer images.