# -*- coding: utf-8 -*-
"""
Created on Mon Aug  2 08:49:48 2021

@author: uKey
"""

from pathlib import Path

import torch
import torchvision
from torchvision import transforms

import numpy as np
import matplotlib.pyplot as plt
from model_acc80 import Net

def data_transform(data_path):
    data = np.load(data_path, allow_pickle = True)
    transform = transforms.Compose([transforms.ToTensor()])
    data = transform(data)
    data = data.permute(1, 2, 0)
    data = data.unsqueeze(0)
    data = data.unsqueeze(0)
    return data

feature_block = []
def forward_hook(module, data_in, feature_out):
    feature_block.append(feature_out)

def feature_imshow(inp,pic_name):    
    inp = inp.numpy().transpose((1, 2, 0))    #e.g. (3, 4338, 4338)→(4338, 4388, 3) 图片输出格式要求
    mean = np.array([0.5, 0.5, 0.5])
    std = np.array([0.5, 0.5, 0.5])
    inp = std * inp + mean
    inp = np.clip(inp, 0, 1)    #将inp中的数值限制到0至1
    
    plt.imshow(inp)
    plt.savefig(pic_name+'.png')
    
    plt.pause(0.01)  # pause a bit so that plots are updated

if __name__ == '__main__':
    feature_block = []
    feature_block = []
    img_path = Path('./0.2898k3/2898k3fake.jpg')
    data_path = Path('./0.2898k3/2898k3.npy')
    net_weight_path = Path('./acc80.pkl')

    data = data_transform(data_path)
    net = Net()
    net = torch.nn.DataParallel(net)
    net.load_state_dict(torch.load(net_weight_path)['net'])
    net.module.conv1_d.register_forward_hook(forward_hook)
    output = net(data)
    info = feature_block[0].detach().cpu().transpose(1, 0)    #e.g. (1, 64, 540, 540)→(64, 1, 540, 540)
    img_batch = torchvision.utils.make_grid(info)             #e.g. (64, 1, 540, 540)→(3, 4338, 4338) 将图像块平铺
    