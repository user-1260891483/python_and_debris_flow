# -*- coding: utf-8 -*-
"""
Created on Wed Nov 10 10:55:33 2021

0 DEM
1 H1
2 H2
3 H3
4 H4
5 ROCK
6 SOIL

网络流
data 8*1280*1280 

@author: uKey
"""

import torch
from torch import nn
import torch.nn.functional as F
# import torch
# from torchinfo import summary
# import hiddenlayer as h    #绘图模块

class ChannelSE(nn.Module):
    def __init__(self, channel, reduction=2):
        super(ChannelSE, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Sigmoid()
        )
    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y.expand_as(x)

class SpatialSE(nn.Module):
    def __init__(self, kernel_size=3):
        super(SpatialSE, self).__init__()
 
        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1
 
        self.conv = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid() 
    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)    #对dim指示的维度取平均值
        max_out, _ = torch.max(x, dim=1, keepdim=True)  #keepdim保持其它维度形状不变
        y = torch.cat((avg_out, max_out), dim=1)
        y = self.conv(y)
        return x * y.expand_as(x)

class FuseBlock(nn.Module):
    def __init__(self):
        super(FuseBlock, self).__init__()
        self.relu = nn.ReLU()
        self.conv2d_1 = nn.Conv2d(16, 16, kernel_size = (3, 3), stride = (2, 2), padding = (1, 1))
        self.conv2d_2 = nn.Conv2d(16, 16, kernel_size = (3, 3), stride = (2, 2), padding = (1, 1))
        self.conv2d_3 = nn.Conv2d(16, 8, kernel_size = (3, 3), stride = 2, padding = 1)
        self.mp2 = nn.MaxPool2d(2)
        self.mp4 = nn.MaxPool2d(4)
        self.bn1 = nn.BatchNorm2d(16)
        self.bn2 = nn.BatchNorm2d(8)
        
    def forward(self,x):
        r1 = self.mp2(x)
        r2 = self.mp4(x)
        x = self.relu(self.conv2d_1(x))    #[14,40,40]
        r3 = self.mp2(x)
        x = x + r1
        x = self.relu(self.conv2d_2(x))    #[14,20,20]
        x = x  + r2 + r3
        x = self.relu(self.bn2(self.conv2d_3(x)))    #[8,10,10]
        return x    
    
class Net(nn.Module):
    def __init__(self, group_num = 4, group_dem = 32, group_ms = 16, n_classes = 6):
        super(Net, self).__init__()
        #dem
        self.group_dem = group_dem    #dem输出通道数
        self.conv1_d  = nn.Conv2d(1,  48, kernel_size = (5, 5), stride = 2, padding = 2)
        self.conv2_d  = nn.Conv2d(48, 48, kernel_size = (5, 5), stride = 2, padding = 2)
        self.conv3_d  = nn.Conv2d(48, self.group_dem, kernel_size = (3, 3), stride = 2, padding = 1)
        self.conv4_d  = nn.Conv2d(self.group_dem, self.group_dem, kernel_size = (3, 3), stride = 2, padding = 1)
        self.mp_d = nn.MaxPool2d(2)
        self.bn_d1 = nn.BatchNorm2d(48)
        self.bn_d2 = nn.BatchNorm2d(self.group_dem)
        #ms
        self.group_ms = group_ms    #ms输出通道数
        self.conv1_ms = nn.Conv3d(1,  24, kernel_size = (2, 5, 5), stride = (1, 2, 2), padding = (0, 2, 2))
        self.conv2_ms = nn.Conv3d(24, 24, kernel_size = (2, 5, 5), stride = (1, 2, 2), padding = (0, 2, 2))
        self.conv3_ms = nn.Conv3d(24, self.group_ms, kernel_size = (3, 3, 3), stride = (1, 2, 2), padding = (1, 1, 1))
        self.conv4_ms = nn.Conv3d(self.group_ms, self.group_ms, kernel_size = (2, 3, 3), stride=(1, 2, 2),padding=(0, 1, 1))
        self.mp_ms = nn.MaxPool3d((2, 2, 2), stride = (1, 2, 2))
        self.bn_ms1 = nn.BatchNorm3d(24)
        self.bn_ms2 = nn.BatchNorm3d(self.group_ms)
        #rock
        self.conv1_r = nn.Conv2d(1, 2, kernel_size = (5, 5), stride = 2, padding = 2)
        self.conv2_r = nn.Conv2d(2, 2, kernel_size = (5, 5), stride = 2, padding = 2)
        self.conv3_r = nn.Conv2d(2, 1, kernel_size = (3, 3), stride = 2, padding = 1)
        self.mp_r = nn.MaxPool2d(2)
        self.bn_r = nn.BatchNorm2d(2)
        #soil
        self.conv1_s = nn.Conv2d(1, 2, kernel_size = (5, 5), stride = 2, padding = 2)
        self.conv2_s = nn.Conv2d(2, 2, kernel_size = (5, 5), stride = 2, padding = 2)
        self.conv3_s = nn.Conv2d(2, 1, kernel_size = (3, 3), stride = 2, padding = 1)
        self.mp_s = nn.MaxPool2d(2)
        self.bn_s = nn.BatchNorm2d(2)
        #plant
        self.conv1_p = nn.Conv2d(1, 2, kernel_size = (5, 5), stride = 2, padding = 2)
        self.conv2_p = nn.Conv2d(2, 2, kernel_size = (5, 5), stride = 2, padding = 2)
        self.conv3_p = nn.Conv2d(2, 2, kernel_size = (3, 3), stride = 2, padding = 1)
        self.mp_p = nn.MaxPool2d(2)
        self.bn_p = nn.BatchNorm2d(2)
        #fuse
        self.fuse1 = FuseBlock()
        self.fuse2 = FuseBlock()
        self.fuse3 = FuseBlock()
        self.fuse4 = FuseBlock()
        #fc
        self.fc1 = nn.Linear(800, 256)
        self.fc2 = nn.Linear(256, n_classes)
        #utils
        self.group_num = group_num    #数据的组数，用于shuffle
        self.split_dem = self.group_dem//self.group_num  #[32//4]
        self.split_ms  = self.group_ms//self.group_num   #[16//4]
        self.relu = nn.ReLU()
    def forward(self, x):
        #data
        dem  = x[:, :, 0, :, :]    #[4,1,1280,1280]
        ms   = x[:, :, 1:5, :, :]  #[4,1,4,1280,1280]
        rock = x[:, :, 5, :, :]    #[4,1,1280,1280]
        soil = x[:, :, 6, :, :]    #[4,1,1280,1280]
        plant = x[:, :, 7, :, :]
        #dem
        o_d = self.relu(self.bn_d1(self.conv1_d(dem)))    #[640,640]
        r_d1 = self.mp_d(o_d)
        o_d = self.relu(self.conv2_d(o_d))    #[320,320]
        o_d = o_d + r_d1
        o_d = self.relu(self.conv3_d(o_d))    #[160,160]
        r_d2 = self.mp_d(o_d)
        o_d = self.relu(self.conv4_d(o_d))    #[80,80]
        o_d = o_d + r_d2
#         print('dem', o_d.shape)
        #ms
        o_ms = self.relu(self.conv1_ms(ms))    #[3,640,640]
        r_ms1 = self.mp_ms(o_ms)
        o_ms = self.relu(self.conv2_ms(o_ms))  #[2,320,320]
        o_ms = o_ms + r_ms1
        o_ms = self.relu(self.conv3_ms(o_ms))  #[2,160,160]
        r_ms2 = self.mp_ms(o_ms)
        o_ms = self.relu(self.conv4_ms(o_ms))  #[4,16,1,80,80]
        o_ms = (o_ms + r_ms2).squeeze(2)
#         print('yg', o_ms.shape)
        #rock
        o_r = self.relu(self.bn_r(self.conv1_r(rock)))    #[2,640,640]
        r_r = self.mp_r(o_r)
        o_r = self.relu(self.conv2_r(o_r))     #[2,320,320]
        o_r = o_r + r_r
        o_r = self.relu(self.conv3_r(o_r))     #{1,160,160}
#         o_r = self.relu(self.conv4_r(o_r))     #{1,80,80}
        o_r = self.mp_r(o_r)
#         print('rock', o_r.shape)
        #soil
        o_s = self.relu(self.bn_s(self.conv1_s(soil)))   #[2,640,640]
        r_s = self.mp_s(o_s)                 #[4,2,320,320]
        o_s = self.relu(self.conv2_s(o_s))   #[4,2,320,320]
        o_s = o_s + r_s
        o_s = self.relu(self.conv3_s(o_s))   #{1,160,160}
        o_s = self.mp_s(o_s)  
#         print('soil', o_s.shape)
        #plant
        o_p = self.relu(self.bn_s(self.conv1_p(soil)))   #[2,640,640]
        r_p = self.mp_s(o_p)
        o_p = self.relu(self.conv2_p(o_p))   #[4,2,320,320]
        o_p = o_p + r_p
        o_p = self.relu(self.conv3_p(o_p))
#         o_p = self.relu(self.conv4_p(o_p))
        o_p = self.mp_s(o_p)
#         print('plant', o_p.shape)
        #shuffle and concatenate   
        o_g1 = torch.cat((o_d[:,0:self.split_dem,:], o_ms[:,0:self.split_ms,:], o_r,o_s,o_p),1)
        o_g2 = torch.cat((o_d[:,self.split_dem:2*self.split_dem,:], o_ms[:,self.split_ms:2*self.split_ms,:], o_r,o_s,o_p),1)
        o_g3 = torch.cat((o_d[:,2*self.split_dem:3*self.split_dem,:], o_ms[:,2*self.split_ms:3*self.split_ms,:], o_r,o_s,o_p),1)
        o_g4 = torch.cat((o_d[:,3*self.split_dem:,:], o_ms[:,3*self.split_ms:,:], o_r,o_s,o_p),1)
        o1 = self.fuse1(o_g1)
        o2 = self.fuse2(o_g2)
        o3 = self.fuse3(o_g3)
        o4 = self.fuse4(o_g4)
        o = o1 + o2 + o3 + o4
        o = o.view(o.size(0), -1)
        o = self.fc1(o)
        o = self.fc2(o)
        return o
