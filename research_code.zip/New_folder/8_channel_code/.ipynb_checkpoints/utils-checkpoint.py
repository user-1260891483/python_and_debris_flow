# -*- coding: utf-8 -*-
"""
Created on Tue Nov  9 08:19:50 2021

!!!np数据要用permute(1，0，2)转一下，不知道为啥ToTensor维度会变成1280， 7， 1280

@author: uKey
"""

import random
import json
from pathlib import Path
import torch
from torch import nn
import torch.nn.functional as F
from torch.autograd import Variable
from torch.utils.data import Dataset
import numpy as np

class SimpleDateset(Dataset):
    def __init__(self,data_file,transform):
        with open(data_file,'r') as f:
            self.meta = json.load(f)
        self.transform_d = transform
    def __getitem__(self,i):
        data_path = Path(self.meta['data_path'][i])
        data = np.load(data_path,allow_pickle=True)
        data = self.transform_d(data)
        data = data.permute(1,2,0)  
        data = data.unsqueeze(0)      
        label = int(self.meta['data_labels'][i])
        return data,label
    def __len__(self):
        return len(self.meta['data_labels'])

class Tloss(nn.Module):
    def __init__(self, n_classes = 6, alpha = 2):
        super(Tloss, self).__init__()
        self.alpha = alpha
    def forward(self, res, labels):
        p = F.softmax(res, dim = 1)
        loss = self.cal_loss(p, labels)
        return loss
    def cal_loss(self, prob_m, labels):
        loss = 0
        for i in range(prob_m.shape[0]):
            if labels[i] <= 2:
                one_loss = -self.alpha*torch.log(torch.tensor(1)- torch.sum(prob_m[i, 3:]))
            else:
                one_loss = -self.alpha*torch.log(torch.tensor(1)- torch.sum(prob_m[i, :3]))
            loss += one_loss
        return loss
    
class FocalLoss(nn.Module):
    def __init__(self, class_num, alpha=None, gamma=2.2, size_average=True):
        super(FocalLoss, self).__init__()
        if alpha is None:
            self.alpha = Variable(torch.ones(class_num, 1))
        else:
            if isinstance(alpha, Variable):
                self.alpha = alpha
            else:
                self.alpha = Variable(alpha)
        self.gamma = gamma
        self.class_num = class_num
        self.size_average = size_average

    def forward(self, inputs, targets):
        N = inputs.size(0)
        C = inputs.size(1)
        P = F.softmax(inputs, dim = 1)
        
        class_mask = inputs.data.new(N, C).fill_(0)
        class_mask = Variable(class_mask)
        ids = targets.view(-1, 1)
        class_mask.scatter_(1, ids.data, 1.)
        #print(class_mask)

        if inputs.is_cuda and not self.alpha.is_cuda:
            self.alpha = self.alpha.cuda()
        alpha = self.alpha[ids.data.view(-1)]

        probs = (P*class_mask).sum(1).view(-1,1)

        log_p = probs.log()
        #print('probs size= {}'.format(probs.size()))
        #print(probs)

        batch_loss = -alpha*(torch.pow((1-probs), self.gamma))*log_p 
        #print('-----bacth_loss------')
        #print(batch_loss)

        if self.size_average:
            loss = batch_loss.mean()
        else:
            loss = batch_loss.sum()
        return loss
    
def setup_seed(seed):
      torch.manual_seed(seed)
      torch.cuda.manual_seed_all(seed)
      np.random.seed(seed)
      random.seed(seed)
      torch.backends.cudnn.deterministic = True