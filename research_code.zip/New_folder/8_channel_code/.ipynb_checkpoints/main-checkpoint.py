# -*- coding: utf-8 -*-
"""
Created on Tue Nov  9 08:10:55 2021

@author: uKey
"""

import torch
from torch.utils.data import DataLoader
from torch import nn
from torch.autograd import Variable
torch.cuda.empty_cache()    #!!! clear cuda memory
from torchvision.transforms import transforms
import argparse
from pathlib import Path

from utils import SimpleDateset, Tloss, FocalLoss
from model import Net

#log变量
log_train_loss = []
log_train_acc = []
log_test_acc = []
log_0_1_acc = []
log_test_loss = []
log_best_epoch = 0
log_best_acc  = [0, 0]
log_best_pred = []
log_test_real = []

#参数设定
parser = argparse.ArgumentParser()
parser.add_argument('--batch_size',  type=int,   default=4,       help='input batch size')
parser.add_argument('--max_epoch',   type=int,   default=100,      help='max training iterations')
parser.add_argument('--lr',          type=float, default=0.00005,  help='learning rate, default=0.0001')
parser.add_argument('--num_workers', type=int,   default=2,       help='num of workers, default=8')
parser.add_argument('--class_num',   type=int,   default=6,       help='num of classes, landslide=6')
option = parser.parse_args()

print('#'*10 + 'Net_Info' + '#'*10)
print('max_epoch\t{:>10}\nclass_num\t{:>10}\nbatch_size\t{:>10}\nlearning_rate\t{:>10}\nnum_workers\t{:>10}'
      .format(option.max_epoch, option.class_num, option.batch_size, option.lr, option.num_workers))
print("Use", torch.cuda.device_count(), "GPUs.")
print('#'*28)

#训练集/测试集
transform = transforms.Compose([transforms.ToTensor()])

train_path = Path('train_2.json')
train_dataset = SimpleDateset(train_path,transform)
train_dataloader = DataLoader(train_dataset,batch_size=option.batch_size,shuffle=True,num_workers=option.num_workers)

test_path = Path('test_2.json')
test_dataset = SimpleDateset(test_path,transform)
test_dataloader = DataLoader(test_dataset,batch_size=option.batch_size,shuffle=False,num_workers=option.num_workers)

#网络
net = Net(n_classes = option.class_num).cuda()
net = torch.nn.DataParallel(net)
#损失函数
ce_loss = nn.CrossEntropyLoss()    # FocalLoss(class_num = option.class_num)
t_loss = Tloss(option.class_num, 2)
#优化
optimizer = torch.optim.Adam(net.parameters(), lr = option.lr)
#模型参数保存路径
checkpoint_dir = Path('./model_save')
if not checkpoint_dir.exists():
    checkpoint_dir.mkdir()
    
print("Initialize Complete.Wait for training...")

for epoch in range(1, option.max_epoch+1):
    train_loss = 0
    train_correct = 0
    train_total = 0
    net.train()
    for i,info in enumerate(train_dataloader):
        #梯度清零
        optimizer.zero_grad()
        #数据载入
        data, label = info
        data = data.type(torch.FloatTensor)
        data, label = Variable(data.cuda()), Variable(label.cuda())
        #训练输出
        res = net(data)
        #损失计算
        loss = ce_loss(res, label) + t_loss(res, label)
        #反向传播
        loss.backward()
        optimizer.step()
        #进度信息
        _,predicted = torch.max(res.data,1)
        
        train_correct += predicted.eq(label.data).cpu().sum()
        train_total += label.size(0)
        train_loss += loss.item()
    print('[Epoch:%3d] AvgLoss: %.05f | Acc: %.3f%% '
          % (epoch, train_loss/(i+1), 100.*train_correct/train_total))
    #训练记录
    log_train_loss.append(round(train_loss/(i+1), 3))
    log_train_acc.append(round(100.*float(train_correct/train_total), 3))  
    #测试
    net.eval()    
    print('Test Epoch %d'%(epoch))
    with torch.no_grad():
        test_correct = 0
        test_total = 0
        correct_01 = 0
        temp_r = []
        temp_p = []
        for info in test_dataloader:
            data, label = info
            data = data.type(torch.FloatTensor)
            data, label = Variable(data.cuda()), Variable(label.cuda())
            res = net(data)
            test_loss = ce_loss(res, label) + t_loss(res, label)
            _,predicted = torch.max(res.data,1)
            r = label.tolist()
            p = predicted.tolist()
            temp_r += r
            temp_p += p
            print('real ',r,' pred',p)
            for r_,p_ in zip(r, p):
                if(r_<=2 and p_<=2) or (r_>=3 and p_>=3):
                    correct_01 += 1       
            test_total += label.size(0)
            test_correct += (predicted == label).sum()
            
        test_acc = round(100.*float(test_correct/test_total), 3)
        acc_01   = round(100.*correct_01/test_total, 3)
        print('Test acc：%.3f%%' % test_acc)
        print('0-1 acc: %.3f%%' % acc_01)
        print('Test loss: %.5f' % test_loss.item())
        #测试记录
        log_test_acc.append(test_acc)
        log_0_1_acc.append(acc_01)
        log_test_loss.append(round(test_loss.item(),3))
        if test_acc >= log_best_acc[0] and epoch>10:
            log_best_epoch = epoch
            log_best_acc   = [test_acc, acc_01]
            log_best_pred = temp_p
            log_test_real = temp_r
            #保存模型参数
            outfile = checkpoint_dir/'{:d}.pkl'.format(epoch)
            torch.save({'epoch':epoch, 'net':net.state_dict()}, outfile)
            print('Save {:d}.pkl done.'.format(epoch))

            
#写入记录
with open('log.txt', 'a+') as logfile:
    logfile.write('train_loss\n')
    logfile.write(str(log_train_loss) + '\n')
    logfile.write('train_acc\n')
    logfile.write(str(log_train_acc) + '\n')
    logfile.write('test_acc\n')
    logfile.write(str(log_test_acc) + '\n')
    logfile.write('0_1_acc\n')
    logfile.write(str(log_0_1_acc) + '\n')
    logfile.write('test_loss\n')
    logfile.write(str(log_test_loss) + '\n')
    logfile.write('best_epoch\n')
    logfile.write(str(log_best_epoch) + '\n')
    logfile.write('best_acc\n')
    logfile.write(str(log_best_acc) + '\n')
    logfile.write('best_pred\n')
    logfile.write(str(log_best_pred) + '\n')
    logfile.write('real_label\n')
    logfile.write(str(log_test_real) + '\n')
print('Save log done.')